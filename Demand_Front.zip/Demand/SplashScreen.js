import React from 'react';
import { View, Text, ImageBackground, StyleSheet } from 'react-native';

const SplashScreen = () => {
  return (
    <ImageBackground
      source={require('./assets/screenWithVersion.png')} // Replace with your image path
      style={styles.backgroundImage}
    >
      {/* <View style={styles.container}>
        <Text style={styles.text}>PlantPal</Text>
      </View> */}
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover', // This will make the image cover the entire screen
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 50,
    color: 'white', // Set text color to be visible on the image
    fontWeight: 'bold',
  },
});

export default SplashScreen;
