import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet, TouchableHighlight, TouchableOpacity, Image} from 'react-native';
import axios from 'axios';
import { useNavigation } from '@react-navigation/native';
import { Picker } from '@react-native-picker/picker';

const baseUrl = 'http://192.168.1.10:5000';
const endpoint = '/predict';

const cities = [
  "Weragampita",
  "Welisara",
  "Weligama",
  "Wattegama",
  "Wattala",
  "Vavuniya",
  "Valvedditturai",
  "Trincomalee",
  "Tirukkalkudah",
  "Timbirigasyaya",
  "Taralanda",
  "Tangalle",
  "Tammannekulama",
  "Talawakele",
  "Sigiriya",
  "Ratnapura",
  "Puttalam",
  "Puliyadikuda",
  "Polonnaruwa",
  "Point Pedro",
  "Pita Kotte",
  "Peliyagoda",
  "Panadura",
  "Nuwara Eliya",
  "New Town",
  "Negombo",
  "Mulleriyawa",
  "Moratuwa",
  "Monaragala",
  "Mohottiwatta",
  "Minuwangoda",
  "Matara",
  "Mannar",
  "Maharagama",
  "Kurunegala",
  "Kumbalwella",
  "Kuliyapitiya",
  "Sri Jayewardenepura Kotte",
  "Kotikawatta",
  "Kolonnawa",
  "Kilinochchi",
  "Kelaniya",
  "Katunayaka",
  "Kandy",
  "Kandana",
  "Kalutara",
  "Kalmunai",
  "Kallady",
  "Kadugannawa",
  "Jaffna",
  "Ja Ela",
  "Horana South",
  "Homagama",
  "Hingurakgoda",
  "Hikkaduwa",
  "Hendala",
  "Hatton",
  "Haputale",
  "Hanwella Ihala",
  "Hambantota",
  "Gampola",
  "Gampaha",
  "Galle",
  "Galkissa",
  "Dambulla",
  "Colombo",
  "Chilaw",
  "Beruwala",
  "Bentota",
  "Batticaloa",
  "Battaramulla South",
  "Badulla",
  "Anuradhapura",
  "Ampara",
  "Ambalangoda",
];

const CropSelectorScreen = () => {
  const navigation = useNavigation();

  const [cityName, setCityName] = useState('');
  const [waterLitersPerMonth, setWaterLitersPerMonth] = useState('');
  const [landSize, setLandSize] = useState('');
  const [noPlants, setNoPlants] = useState('');
  const [nethouseCost, setNethouseCost] = useState('');
  const [plantingCost, setPlantingCost] = useState('');
  const [maintainCostPerMonth, setMaintainCostPerMonth] = useState('');
  const [flowerYield, setFlowerYield] = useState('');
  const [suggestion, setSuggestion] = useState('');
  const [showSuggestion, setShowSuggestion] = useState(true);

  

  const cropImages = {
    Rose: require('./assets/8_rose.png'),
    Anthurium: require('./assets/2_anth.png'),
    Chrysanthemum:require('./assets/4_chris.png'),
    Carnation:require('./assets/3_carn.png'),
    Orchid:require('./assets/7_orch.png'),
    Gerbera:require('./assets/5_gerb.png'),
    Lily:require('./assets/6_lil.png'),
    Alstroemeria:require('./assets/1_alstro.png'),
  };
  

  const handlePredictCrop = async () => {
    try {

      // Calculate annual water availability based on monthly input
      const annualWaterLiters = parseInt(waterLitersPerMonth) * 12;
      // Calculate annual maintenance cost based on monthly input
      const annualMaintainCost = parseInt(maintainCostPerMonth) * 12;



      const response = await axios.post(`${baseUrl}${endpoint}`, {
        city_name: cityName,
        water_liters_per_yr: annualWaterLiters,
        land_size_in_sqft: parseInt(landSize),
        no_of_plants: parseInt(noPlants),
        nethouse_land_preparation_cost: parseInt(nethouseCost),
        planting_cost: parseInt(plantingCost),
        maintaining_cost: annualMaintainCost,
        flower_yield_per_yr: parseInt(flowerYield)
      });

      const suggestion = response.data.plant_suggestion;
      setSuggestion(suggestion);
      setShowSuggestion(true); // Reset showSuggestion state to true


      // if (suggestion) {
      //   Alert.alert('Best Crop to Grow', `Recommendation: ${suggestion}`);
      // }

    } catch (error) {
      console.error('Error predicting crop:', error);
      Alert.alert('Error', 'An error occurred while predicting crop.');
    }
  };

  const navigateToApp = () => {
    navigation.goBack();
  };

  const handleShowSuggestion = () => {
    setShowSuggestion(true);
  };


  return (
    <View style={styles.container}>
      <View style={styles.formContainer}>
          <Text style={styles.inputTitle}>Where Are You Located?</Text>
          <View style={styles.pickerContainer}>
            <Picker
              selectedValue={cityName}
              onValueChange={value => setCityName(value)}
              // style={styles.picker}
            >
              <Picker.Item label="Select your City" value="" color="#999" />
              {cities.map(city => (
                <Picker.Item key={city} label={city} value={city} />
              ))}
            </Picker>
          </View>
       
          <Text style={styles.inputTitle}>How Much Space Do You Have?</Text>
          <TextInput
            placeholder="Land Size (in square feet)"
            value={landSize}
            onChangeText={text => setLandSize(text)}
            style={styles.inputField}
            keyboardType="numeric"
          />
  
        <Text style={styles.inputTitle}>How Many Plants Are You Starting With?</Text>
        <TextInput
        placeholder="Initial Plant Count"
        value={noPlants}
        onChangeText={text => setNoPlants(text)}
        style={styles.inputField}
        keyboardType="numeric"
      />
        <Text style={styles.inputTitle}>What's Your Initial Budget?</Text>
          <View style={styles.inputFieldGroup}>
            <TextInput
              placeholder="Nethouse/Land Prep"
              value={nethouseCost}
              onChangeText={text => setNethouseCost(text)}
              style={[styles.inputField, styles.inputFieldSideBySide]}
              keyboardType="numeric"
            />
            <TextInput
              placeholder="Initial Planting"
              value={plantingCost}
              onChangeText={text => setPlantingCost(text)}
              style={[styles.inputField, styles.inputFieldSideBySide]}
              keyboardType="numeric"
            />
          </View>
      
        <Text style={styles.inputTitle}>Monthly Resources?</Text>

         <View style={styles.inputFieldGroup}>
          <TextInput
            placeholder="Water litres/month"
            value={waterLitersPerMonth}
            onChangeText={text => setWaterLitersPerMonth(text)} // Update monthly value
            style={[styles.inputField, styles.inputFieldSideBySide]}
            keyboardType="numeric"
          />
      
          <TextInput
            placeholder="Upkeep Budget"
            value={maintainCostPerMonth}
            onChangeText={text => setMaintainCostPerMonth(text)} // Update monthly value
            style={[styles.inputField, styles.inputFieldSideBySide]}
            keyboardType="numeric"
          />
         </View>

      <Text style={styles.inputTitle}>Expected Flowers Each Year?</Text>
      <TextInput
        placeholder="Expected Annual Cut Flower Yield"
        value={flowerYield}
        onChangeText={text => setFlowerYield(text)}
        style={styles.inputField}
        keyboardType="numeric"
/>
        
<TouchableHighlight
          style={[
            styles.button,
            {
              backgroundColor: !cityName ||
                !waterLitersPerMonth ||
                !landSize ||
                !noPlants ||
                !nethouseCost ||
                !plantingCost ||
                !maintainCostPerMonth ||
                !flowerYield
                ? 'rgba(211, 211, 211, 0.5)' // Dull color when disabled
                : '#7aae64', // Original color
            },
          ]}
          onPress={handlePredictCrop}
          disabled={
            !cityName ||
            !waterLitersPerMonth ||
            !landSize ||
            !noPlants ||
            !nethouseCost ||
            !plantingCost ||
            !maintainCostPerMonth ||
            !flowerYield
          }
          underlayColor="#e8fbe8"
        >
          <Text style={styles.buttonText}>Get Suggestion</Text>
        </TouchableHighlight>

        {showSuggestion && suggestion !== '' && (
          <View style={styles.suggestionContainer}>
            <View style={styles.suggestionBox}>
              <Text style={styles.suggestionText}>Best crop to grow</Text>
              {cropImages[suggestion] && (
                <Image
                  source={cropImages[suggestion]}
                  style={styles.cropImage}
                />
              )}

              <Text style={styles.suggestionValue}>{suggestion}</Text>
              <TouchableOpacity
                style={styles.gotItButton}
                onPress={() => setShowSuggestion(false)} // Hide the suggestion box when "Got It" is pressed
              >
                <Text style={styles.gotItButtonText}>Got it!</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#f4f4f4',
  },
  formContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    elevation: 4,
    width: '100%',
  },
  // inputGroup: {
  //   marginBottom: 10,
  // },
  inputTitle: {
    fontSize: 16,
    color: '#7aae64',
    marginBottom: 5,
  },
  // picker: {
  //   backgroundColor: 'white',
  //   borderWidth: 1,
  //   borderColor: '#7aae64',
  //   borderRadius: 5,
  // },
  inputField: {
    marginBottom: 10,
    padding: 10,
    borderColor: '#7aae64',
    borderWidth: 1,
    borderRadius: 5,
  },
  sectionDivider: {
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 18,
    color: '#7aae64',
    fontWeight: 'bold',
  },
  // suggestionText: {
  //   marginTop: 20,
  //   fontSize: 18,
  //   color: '#7aae64',
  //   fontWeight: 'bold',
  //   alignSelf:'center'
  // },
  pickerContainer: {
    borderColor: '#7aae64',
    borderWidth: 1,
    borderRadius: 5,
    // padding: 1,
    marginBottom: 10,
  },
  inputFieldGroup: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  
  inputFieldSideBySide: {
    flex: 1,
    marginRight: 5,
  },

  button: {
    backgroundColor: '#87B673',
    paddingHorizontal: 5,
    paddingVertical: 8,
    borderRadius: 8,
    // borderWidth: 0,
    // borderColor: 'black',
    marginVertical: 5,
    // width: 150,
    shadowColor: 'black',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    // elevation: 10,
    // height: 50,
  },
  buttonText: {
    color: '#e8fbe8',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    // marginTop: 25,
  },
  suggestionContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)'
  },
  suggestionBox: {
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
    padding: 15,
    width: '80%',
    height:'50%'
  },
  suggestionText: {
    fontSize: 20,
    color: '#7aae64',
    margin: 10,
    alignSelf: 'center'
  },
  suggestionValue: {
    fontSize: 22,
    marginTop: 5,
    alignSelf: 'center',
    fontWeight: 'bold',
  },


  // ... (your existing suggestionBox, suggestionText, and suggestionValue styles)
  gotItButton: {
    marginTop: 15,
    alignSelf: 'center',
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#7aae64',
    borderRadius: 5,
  },
  gotItButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 22,
    
  },

  cropImage: {
    width: 150, // Adjust the width as needed
    height: 150, // Adjust the height as needed
    resizeMode: 'contain',
    alignSelf: 'center',
    margin: 10
  },
});

export default CropSelectorScreen;
