import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import SplashScreen from './SplashScreen';
import HomeScreen from './HomeScreen'; // Import the HomeScreen component
import DiseaseScreen from './DiseaseScreen';
import DemandScreen from './DemandScreen';
import BeginnersScreen from './BeginnersScreen';
import VarietyIdentifierScreen from './VarietyIdentifierScreen';
import CropSelectorScreen from './CropSelectorScreen';
import GrowthScreen from './GrowthScreen';
import GrowthSubScreenOne from './GrowthSubScreenOne';
import GrowthSubScreenTwo from './GrowthSubScreenTwo';
import DiseaseSubScreenOne from './DiseaseSubScreenOne';
import DemandSubScreenOne from './DemandSubScreenOne';
import DemandSubScreenTwo from './DemandSubScreenTwo';

const Stack = createStackNavigator();

const App = () => {

  const [isAppReady, setIsAppReady] = useState(false);

  useEffect(() => {
    // Simulate some app initialization
    setTimeout(() => {
      setIsAppReady(true);
    }, 10000); // Wait for 2 seconds to simulate loading
  }, []);

  if (!isAppReady) {
    return <SplashScreen />;
  }

  return (
    <NavigationContainer>

      
<Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerStyle: {
            // backgroundColor: '#1faa1f', // Set the navigation bar color
            backgroundColor: '#7aae64'
            // borderBottomWidth: 2, // Add border to the bottom of the header
            // borderBottomColor: 'black',
          },
          headerTintColor: 'black', // Set the text color in navigation bar
          headerTitleStyle: {
            fontSize: 24, // Increase the font size of header text
            fontWeight: 'bold', // Make the header text bold
          },
        }}
      >
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Monitor growth" component={GrowthScreen} />
        <Stack.Screen name="Growth one" component={GrowthSubScreenOne} />
        <Stack.Screen name="Growth two" component={GrowthSubScreenTwo} />
        <Stack.Screen name="Diagnose your plant" component={DiseaseScreen} />
        <Stack.Screen name="Disease one" component={DiseaseSubScreenOne} />
        {/* <Stack.Screen name="Demand Prediction" component={DemandScreen} /> */}
        <Stack.Screen name="Supply Prediction" component={DemandSubScreenOne} />
        <Stack.Screen name="Demand Prediction" component={DemandSubScreenTwo} />
        <Stack.Screen name="For beginners" component={BeginnersScreen} />
        <Stack.Screen name="VarietyIdentifier" component={VarietyIdentifierScreen} />
        <Stack.Screen name="CropSelector" component={CropSelectorScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;









 

 


// import React, { useState, useEffect } from 'react';
// import { View, Text, Button, Image, TouchableOpacity } from 'react-native';
// import axios from 'axios';
// import * as ImagePicker from 'expo-image-picker';
// import * as Permissions from 'expo-permissions';
// import { Camera } from 'expo-camera';

// const App = () => {
//   const [prediction, setPrediction] = useState('');
//   const [imageUri, setImageUri] = useState(null);
//   const [cameraPermission, setCameraPermission] = useState(null);
//   const [cameraType, setCameraType] = useState(Camera.Constants.Type.back);

//   useEffect(() => {
//     (async () => {
//       const { status } = await Permissions.askAsync(Permissions.CAMERA);
//       setCameraPermission(status === 'granted');
//     })();
//   }, []);

//   const handleImagePicker = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (permissionResult.granted === false) {
//       alert('Permission to access media library is required!');
//       return;
//     }

//     const imageResult = await ImagePicker.launchImageLibraryAsync();
    
//     if (!imageResult.cancelled) {
//       setImageUri(imageResult.assets[0].uri);
//       setPrediction('');
//     }
//   };

//   const takePicture = async () => {
//     if (camera) {
//       const photo = await camera.takePictureAsync();
//       setImageUri(photo.uri);
//       setPrediction('');
//     }
//   };

//   const predictPlant = async () => {
//     if (!imageUri) {
//       alert('Please select an image first.');
//       return;
//     }

//     try {
//       const formData = new FormData();
//       formData.append('image', {
//         uri: imageUri,
//         name: 'image.jpg',
//         type: 'image/jpg',
//       });

//       const response = await axios.post('http://192.168.1.5:5000/predict', formData, {
//         headers: {
//           'Content-Type': 'multipart/form-data',
//         },
//       });

//       setPrediction(response.data.plant_name);
//     } catch (error) {
//       console.error('Error predicting plant:', error);
//     }
//   };

//   let camera;

//   return (
//     <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
//       <View style={{ flexDirection: 'row' }}>
//         <Button title="Camera" onPress={() => setCameraType(prevType => (prevType === Camera.Constants.Type.back ? Camera.Constants.Type.front : Camera.Constants.Type.back))} />
//         <Button title="Gallery" onPress={handleImagePicker} />
//       </View>

//       {cameraPermission && (
//         <Camera style={{ width: 200, height: 200 }} type={cameraType} ref={ref => (camera = ref)} />
//       )}

//       {imageUri && <Image source={{ uri: imageUri }} style={{ width: 200, height: 200 }} />}

//       <TouchableOpacity onPress={takePicture}>
//         <Text>Take Picture</Text>
//       </TouchableOpacity>
//       <TouchableOpacity onPress={predictPlant}>
//         <Text>Predict Plant</Text>
//       </TouchableOpacity>
      
//       {prediction !== '' && (
//         <View style={{ marginTop: 20 }}>
//           <Text>Predicted Plant: {prediction}</Text>
//         </View>
//       )}
//     </View>
//   );
// };

// export default App;


// console.disableYellowBox = true;

// import React, { useState } from 'react';
// import { View, Text, Button, Image, TouchableOpacity } from 'react-native';
// import axios from 'axios';
// import * as ImagePicker from 'expo-image-picker';

// const App = () => {
//   const [prediction, setPrediction] = useState('');

//   const handleImagePicker = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (permissionResult.granted === false) {
//       alert('Permission to access media library is required!');
//       return;
//     }

//     const imageResult = await ImagePicker.launchImageLibraryAsync();
    
//     if (!imageResult.cancelled) {
//       predictPlant(imageResult.assets[0].uri); // Using assets array and uri
//     }
//   };

//   const predictPlant = async (imageUri) => {
//     try {
//       const formData = new FormData();
//       formData.append('image', {
//         uri: imageUri,
//         name: 'image.jpg',
//         type: 'image/jpg',
//       });

//       const response = await axios.post('http://192.168.1.5:5000/predict', formData, {
//         headers: {
//           'Content-Type': 'multipart/form-data',
//         },
//       });

//       setPrediction(response.data.plant_name);
//     } catch (error) {
//       console.error('Error predicting plant:', error);
//     }
//   };

//   return (
//     <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
//       <TouchableOpacity onPress={handleImagePicker}>
//         <Text>Choose an image</Text>
//       </TouchableOpacity>
      
//       {prediction !== '' && (
//         <View style={{ marginTop: 20 }}>
//           <Text>Predicted Plant: {prediction}</Text>
//         </View>
//       )}
//     </View>
//   );
// };

// export default App;
