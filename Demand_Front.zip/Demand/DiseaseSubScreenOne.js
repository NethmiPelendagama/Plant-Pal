// BeginnersScreen.js
import React from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const DiseaseSubScreenOne = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
        <Text> DiseaseSubScreenOne</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default DiseaseSubScreenOne;
