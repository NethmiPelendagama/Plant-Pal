import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, TouchableHighlight } from 'react-native';

export default function YourComponent() {
  const [inputData, setInputData] = useState({
    precipitation: '',
    temp_max: '',
    temp_min: '',
    wind: '',
  });
  const [displayNumber, setDisplayNumber] = useState(null);

  const handleButtonClick = () => {
    // Prepare the data in the required format for your API request
    const requestData = {
      precipitation: [parseFloat(inputData.precipitation)],
      temp_max: [parseFloat(inputData.temp_max)],
      temp_min: [parseFloat(inputData.temp_min)],
      wind: [parseFloat(inputData.wind)],
    };

    // Make an API request to your Flask API
    fetch('http://localhost:5000/predict', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
    })
      .then((response) => response.json())
      .then((data) => {
        // Set the prediction received from the API in the state
        setDisplayNumber(data.prediction);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  return (
    <View style={styles.formContainer}>
      <Text style={styles.inputTitle}>Precipitation</Text>
      <TextInput
        placeholder="Precipitation"
        value={inputData.precipitation}
        onChangeText={(text) => setInputData({ ...inputData, precipitation: text })}
        style={styles.inputField}
        keyboardType="numeric"
      />

      <Text style={styles.inputTitle}>Temp Max</Text>
      <TextInput
        placeholder="Temp Max"
        value={inputData.temp_max}
        onChangeText={(text) => setInputData({ ...inputData, temp_max: text })}
        style={styles.inputField}
        keyboardType="numeric"
      />

      <Text style={styles.inputTitle}>Temp Min</Text>
      <TextInput
        placeholder="Temp Min"
        value={inputData.temp_min}
        onChangeText={(text) => setInputData({ ...inputData, temp_min: text })}
        style={styles.inputField}
        keyboardType="numeric"
      />

      <Text style={styles.inputTitle}>Wind</Text>
      <TextInput
        placeholder="Wind"
        value={inputData.wind}
        onChangeText={(text) => setInputData({ ...inputData, wind: text })}
        style={styles.inputField}
        keyboardType="numeric"
      />

      <TouchableHighlight
        style={styles.button}
        underlayColor="#e8fbe8"
        onPress={handleButtonClick}
      >
        <Text style={styles.buttonText}>Get Prediction</Text>
      </TouchableHighlight>

      {displayNumber !== null && (
        <View style={styles.suggestionBox}>
          <Text style={styles.suggestionText}>Prediction: {displayNumber}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  // Your existing styles remain the same
});
