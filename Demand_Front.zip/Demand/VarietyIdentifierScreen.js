import React, { useState, useEffect } from 'react';
import { View, Text, Button, Image, TouchableOpacity, StyleSheet, TouchableHighlight } from 'react-native';
import axios from 'axios';
import * as ImagePicker from 'expo-image-picker';
import { Camera } from 'expo-camera';
import { useNavigation } from '@react-navigation/native';

import { LogBox } from 'react-native';

// Ignore log notification by message
LogBox.ignoreLogs(['Warning: ...']);

//Ignore all log notifications
LogBox.ignoreAllLogs();

const baseUrl = 'http://192.168.8.104:5000';
const endpoint = '/variety';

const VarietyIdentifierScreen = () => {
  const navigation = useNavigation();

  const [prediction, setPrediction] = useState('');
  const [imageUri, setImageUri] = useState('');
  const [cameraPermission, setCameraPermission] = useState(null);
  const [cameraType, setCameraType] = useState(Camera.Constants.Type.back);
  const [showCamera, setShowCamera] = useState(false);

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestPermissionsAsync();
      setCameraPermission(status === 'granted');
    })();
  }, []);

  const handleImagePicker = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      alert('Permission to access media library is required!');
      return;
    }

    const imageResult = await ImagePicker.launchImageLibraryAsync();
    
    if (!imageResult.cancelled) {
      setImageUri(imageResult.uri);
      setPrediction('');
      setShowCamera(false);
    }
  };

  const handleCapture = async () => {
    if (camera) {
      const photo = await camera.takePictureAsync();
      setImageUri(photo.uri);
      setPrediction('');
      setShowCamera(false);
    }
  };

  const handleCameraPress = () => {
    setImageUri(null); // Reset the imageUri when switching to the camera
    setPrediction(''); // Reset the prediction when switching to the camera
    setShowCamera(true);
  };


  const handleCancelCamera = () => {
    setShowCamera(false);
  };

  const predictPlant = async () => {
    if (!imageUri) {
      alert('Please select an image first.');
      return;
    }

    try {
      const formData = new FormData();
      formData.append('image', {
        uri: imageUri,
        name: 'image.jpg',
        type: 'image/jpg',
      });

      const response = await axios.post(`${baseUrl}${endpoint}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setPrediction(response.data.plant_name);
    } catch (error) {
      console.error('Error predicting plant:', error);
    }
  };

  let camera;

  const navigateToApp = () => {
    navigation.goBack(); // Navigate back to the previous screen (App.js)
  };

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      

      {showCamera && cameraPermission && (
        // <Camera style={{ width: 400, height: 600 }} type={cameraType} ref={ref => (camera = ref)}>
        <Camera style={{ width: 400, height: 800 }} type={cameraType} ref={ref => (camera = ref)} hideTopBar={true}>
          <View style={{ flex: 1, justifyContent: 'flex-end', alignItems: 'center' }}>
          <View style={styles.cameraButtons}>
              <TouchableOpacity onPress={handleCapture} style={styles.captureButton}>
                <Text style={styles.buttonText}>CAPTURE</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={handleCancelCamera} style={styles.cancelButton}>
                <Text style={styles.buttonText}>CANCEL</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Camera>
      )}

      {/* {imageUri && <Image source={{ uri: imageUri }} style={styles.imageBox} />} */}
      {!showCamera && (
        <View style={styles.imageBox} underlayColor="#e8fbe8">
          {imageUri ? (
            <Image
              source={{ uri: imageUri }}
              style={{ width: '100%', height: '100%', resizeMode: 'cover', borderRadius: 8 }}
            />
          ) : (
            <>
              <Image source={require('./assets/plant.png')} style={styles.placeholderImage} />
              <Text style={styles.placeholderText}>Capture an Image</Text>
            </>
          )}
        </View>
      )}

      <View style={styles.container}>
        {/* <Button title="Camera" onPress={handleCameraPress} />
         */}

         <TouchableHighlight style={styles.customButton} onPress={handleCameraPress} underlayColor="#e8fbe8">
         <Text style={styles.customButtonText}>Capture a Photo</Text>
         </TouchableHighlight>

        {/* <Button title="Gallery" onPress={handleImagePicker} /> */}
        <TouchableHighlight style={styles.customButton} onPress={handleImagePicker} underlayColor="#e8fbe8">
         <Text style={styles.customButtonText}>Select from Gallery</Text>
         </TouchableHighlight>

      </View>

      {imageUri && (
        <TouchableHighlight style={styles.button} onPress={predictPlant} underlayColor="#e8fbe8">
          <Text style={styles.buttonText}>See the Variety</Text>
        </TouchableHighlight>
      
        
      )}
      
      {prediction !== '' && (
        <View style={{ marginTop: 20 }}>
          <Text>Predicted Plant: {prediction}</Text>
        </View>
      )}

      {/* Back Button */}
      {/* <Button
        title="Back"
        onPress={() => navigation.goBack()} // Navigate back
      /> */}
    </View>
  );
};

const styles = StyleSheet.create({

  container: {
    flexDirection: 'row',
    paddingHorizontal: 5
  },

  imageBox: {
    // backgroundColor: 'red',
    width:300,
    height: 300,
    marginBottom: 20
  },

  button: {
    backgroundColor: '#87B673',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 8,
    // borderWidth: 0,
    // borderColor: 'black',
    marginVertical: 10,
    marginHorizontal: 5,
    // width: 150,
    shadowColor: 'black',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    // elevation: 10,
    // height: 50,
  },

  buttonText: {
    color: '#e8fbe8',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    // marginTop: 25,
  },

  customButton: {
    backgroundColor: '#ebebeb',
    borderColor: '#87B673',
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 2,
    // borderColor: 'black',
    marginVertical: 10,
    marginHorizontal: 5,
    // width: 150,
    shadowColor: 'black',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  customButtonText: {
    color: '#87B673',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },

  placeholderImage: {
    width: 100,
    height: 100,
    resizeMode: 'cover',
    marginBottom: 10,
  },
  placeholderText: {
    fontSize: 18,
    color: '#888', // Placeholder text color
  },
  cameraButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 20,
    // position:'absolute'
  },
  captureButton: {
    fontSize: 18,
    color: '#888'
  },
  cancelButton: {
    fontSize: 18,
    color: '#888'
  },
})

export default VarietyIdentifierScreen;
