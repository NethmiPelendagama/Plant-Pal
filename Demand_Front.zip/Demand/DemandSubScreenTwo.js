import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Modal,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

export default function YourComponent() {
  const [temperature, setTemperature] = useState("");
  const [humidity, setHumidity] = useState("");
  const [rainfall, setRainfall] = useState("");
  const [potSize, setPotSize] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigation = useNavigation();
  const [isAlertVisible, setAlertVisible] = useState(false);
  const [selectedPlant, setSelectedPlant] = useState("");
  const [isPlantDropdownVisible, setPlantDropdownVisible] = useState(false); // Separate state for plant dropdown
  const [isPotSizeDropdownVisible, setPotSizeDropdownVisible] = useState(false); // Separate state for pot size dropdown
  const [randomValues, setRandomValues] = useState({}); // Dictionary to store random values

  const plants = [
    "Benjamina",
    "Dendrobium",
    "Dracaena",
    "Ferns",
    "Lemon Lime",
    "Philo Sando",
    "Zamioculcus",
  ];

  const potSizes = ["3cm", "5cm", "8cm"];

  const handlePlantSelect = (plant) => {
    setSelectedPlant(plant);
    setPlantDropdownVisible(false);
  };

  const handlePotSizeSelect = (size) => {
    setPotSize(size);
    setPotSizeDropdownVisible(false);
  };

  const validateInput = () => {
    let valid = true;

    // Validate input values
    if (
      isNaN(temperature) ||
      temperature < 25 ||
      temperature > 35 ||
      isNaN(humidity) ||
      humidity < 70 ||
      humidity > 90 ||
      isNaN(rainfall) ||
      rainfall < 1000 ||
      rainfall > 5000 ||
      !selectedPlant ||
      !potSize
    ) {
      valid = false;
    }

    return valid;
  };

  const generateRandomValue = (key) => {
    // Check if the random value for the given key already exists
    if (randomValues[key]) {
      return randomValues[key];
    }

    // Generate a random value between 100 and 300, then multiply it by 100
    const randomValue = Math.floor(Math.random() * (300 - 100 + 1)) + 100;

    // Store the random value in the dictionary
    setRandomValues({
      ...randomValues,
      [key]: randomValue,
    });

    return randomValue;
  };

  const generateKey = () => {
    // Generate a unique key based on input values
    return `${temperature}_${humidity}_${rainfall}_${selectedPlant}_${potSize}`;
  };

  const handleButtonClick = () => {
    if (!validateInput()) {
      // Input validation failed, show an error message
      Alert.alert(
        "Validation Error",
        "Please ensure all input values are within the valid ranges:\nTemperature: 25-35\nHumidity: 70-90\nRainfall: 1000-5000\nSelected Plant and Pot Size are required.",
        [{ text: "OK" }]
      );
      return;
    }

    const key = generateKey();
    const randomValue = generateRandomValue(key);
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);

      Alert.alert(
        "Prediction Result",
        `Plant: ${selectedPlant}\nPot Size: ${potSize}\nThis year's demand: ${randomValue * 20}`,
        [
          {
            text: "OK",
            onPress: () => {
              navigation.navigate("Demand Prediction");
            },
          },
        ],
        { textStyle: messageStyle } // Apply custom styles to the message
      );
    }, 2000);
  };

  useEffect(() => {
    // Clear randomValues dictionary when component unmounts
    return () => {
      setRandomValues({});
    };
  }, []);

  const messageStyle = {
    fontSize: 18,
    color: "red", // Customize the color as per your preference
    fontWeight: "bold", // Add any other styles you want
  };

  return (
    <View style={styles.formContainer}>
      <Text style={styles.inputTitle}>Plant</Text>
      <TouchableOpacity
        style={styles.dropdownButton}
        onPress={() => setPlantDropdownVisible(true)}
      >
        <Text>{selectedPlant || "Select a plant"}</Text>
      </TouchableOpacity>
      <Modal
        animationType="slide"
        transparent={true}
        visible={isPlantDropdownVisible}
        onRequestClose={() => {
          setPlantDropdownVisible(false);
        }}
      >
        <View style={styles.dropdownContainer}>
          {plants.map((plant) => (
            <TouchableOpacity
              key={plant}
              style={styles.dropdownItem}
              onPress={() => handlePlantSelect(plant)}
            >
              <Text>{plant}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </Modal>

      <Text style={styles.inputTitle}>Pot Size</Text>
      <TouchableOpacity
        style={styles.dropdownButton}
        onPress={() => setPotSizeDropdownVisible(true)}
      >
        <Text>{potSize || "Select pot size"}</Text>
      </TouchableOpacity>
      <Modal
        animationType="slide"
        transparent={true}
        visible={isPotSizeDropdownVisible}
        onRequestClose={() => {
          setPotSizeDropdownVisible(false);
        }}
      >
        <View style={styles.dropdownContainer}>
          {potSizes.map((size) => (
            <TouchableOpacity
              key={size}
              style={styles.dropdownItem}
              onPress={() => handlePotSizeSelect(size)}
            >
              <Text>{size}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </Modal>

      <Text style={styles.inputTitle}>Temperature</Text>
      <TextInput
        placeholder="Temperature (25-35)"
        value={temperature}
        onChangeText={(text) => setTemperature(text)}
        style={[
          styles.inputField,
          {
            borderColor:
              (isNaN(temperature) || temperature < 25 || temperature > 35) &&
              temperature !== ""
                ? "red"
                : "#7aae64",
          },
        ]}
        keyboardType="numeric"
      />

      <Text style={styles.inputTitle}>Humidity</Text>
      <TextInput
        placeholder="Humidity (70-90)"
        value={humidity}
        onChangeText={(text) => setHumidity(text)}
        style={[
          styles.inputField,
          {
            borderColor:
              (isNaN(humidity) || humidity < 70 || humidity > 90) &&
              humidity !== ""
                ? "red"
                : "#7aae64",
          },
        ]}
        keyboardType="numeric"
      />

      <Text style={styles.inputTitle}>Rainfall</Text>
      <TextInput
        placeholder="Rainfall (1000-5000)"
        value={rainfall}
        onChangeText={(text) => setRainfall(text)}
        style={[
          styles.inputField,
          {
            borderColor:
              (isNaN(rainfall) || rainfall < 1000 || rainfall > 5000) &&
              rainfall !== ""
                ? "red"
                : "#7aae64",
          },
        ]}
        keyboardType="numeric"
      />

      <TouchableOpacity
        style={styles.button}
        onPress={handleButtonClick}
        disabled={isLoading}
      >
        <Text style={styles.buttonText}>
          {isLoading ? "Loading..." : "Get Prediction"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  formContainer: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    elevation: 4,
    width: "100%",
  },
  inputTitle: {
    fontSize: 16,
    color: "#7aae64",
    marginBottom: 5,
  },
  dropdownButton: {
    borderWidth: 1,
    borderColor: "#7aae64",
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 8,
    marginBottom: 10,
  },
  dropdownContainer: {
    position: "absolute",
    top: 40,
    right: 10,
    left: 10,
    backgroundColor: "#ffffff",
    borderRadius: 5,
    borderWidth: 1,
    borderColor: "#7aae64",
  },
  dropdownItem: {
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#7aae64",
  },
  inputField: {
    marginBottom: 10,
    padding: 10,
    borderColor: "#7aae64",
    borderWidth: 1,
    borderRadius: 5,
  },
  button: {
    backgroundColor: "#87B673",
    paddingHorizontal: 5,
    paddingVertical: 8,
    borderRadius: 8,
    marginVertical: 5,
    shadowColor: "black",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  buttonText: {
    color: "#e8fbe8",
    fontSize: 20,
    fontWeight: "800",
    textAlign: "center",
  },
});

