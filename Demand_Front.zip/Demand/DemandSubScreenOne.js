import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, TouchableHighlight } from 'react-native';
import axios from 'axios';

const DemandSubScreenOne = () => {
  const [prediction, setPrediction] = useState(null);
  const [rainfall, setRainfall] = useState(''); // Default values for testing
  const [temperature, setTemperature] = useState('');
  const [humidity, setHumidity] = useState('');
  const [pot, setPot] = useState('');

  const predict = async () => {
    try {
      const apiUrl = 'http://127.0.0.1/predict'; 
      const requestBody = {
        Rainfall: [parseFloat(rainfall)],
        Temperature: [parseFloat(temperature)],
        Humidity: [parseFloat(humidity)],
        Pot: [parseFloat(pot)],
      };

      const response = await axios.post(apiUrl, requestBody);

      if (response.status === 200) {
        const responseData = response.data;
        if (responseData.hasOwnProperty('prediction')) {
          setPrediction(responseData.prediction);
        } else {
          throw new Error('Prediction not found in response');
        }
      } else {
        throw new Error('Network response was not ok');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <View style={styles.formContainer}>
      <Text style={styles.inputTitle}>Rainfall</Text>
      <TextInput
        placeholder="Rainfall"
        onChangeText={(text) => setRainfall(text)}
        value={rainfall}
        style={styles.inputField}
        keyboardType="numeric"
      />

      <Text style={styles.inputTitle}>Temperature</Text>
      <TextInput
        placeholder="Temperature"
        onChangeText={(text) => setTemperature(text)}
        value={temperature}
        style={styles.inputField}
        keyboardType="numeric"
      />

      <Text style={styles.inputTitle}>Humidity</Text>
      <TextInput
        placeholder="Humidity"
        onChangeText={(text) => setHumidity(text)}
        value={humidity}
        style={styles.inputField}
        keyboardType="numeric"
      />

      <Text style={styles.inputTitle}>Pot</Text>
      <TextInput
        placeholder="Pot"
        onChangeText={(text) => setPot(text)}
        value={pot}
        style={styles.inputField}
        keyboardType="numeric"
      />

      <TouchableHighlight
        style={styles.button}
        underlayColor="#e8fbe8"
        onPress={predict}
      >
        <Text style={styles.buttonText}>Get Prediction</Text>
      </TouchableHighlight>

      {prediction !== null && (
        <View style={styles.suggestionBox}>
          <Text style={styles.suggestionText}>Prediction: {prediction}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  suggestionBox: {
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
    padding: 15,
    width: '80%',
    height: '50%',
    alignSelf: 'center',
    marginTop: 20,
  },
  suggestionText: {
    fontSize: 20,
    color: '#7aae64',
    margin: 10,
    alignSelf: 'center',
  },
  inputTitle: {
    fontSize: 16,
    color: '#7aae64',
    marginBottom: 5,
  },
  inputField: {
    marginBottom: 10,
    padding: 10,
    borderColor: '#7aae64',
    borderWidth: 1,
    borderRadius: 5,
  },
  formContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    elevation: 4,
    width: '100%',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#f4f4f4',
  },
  button: {
    backgroundColor: '#87B673',
    paddingHorizontal: 5,
    paddingVertical: 8,
    borderRadius: 8,
    marginVertical: 5,
    shadowColor: 'black',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  buttonText: {
    color: '#e8fbe8',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
  },
});

export default DemandSubScreenOne;
