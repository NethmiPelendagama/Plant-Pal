import React from 'react';
import { View, Text, StyleSheet, TouchableHighlight, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const DiseaseScreen = () => {
  const navigation = useNavigation();

  const navigateToDiseaseOne = () => {
    navigation.navigate('Disease one');
  };

  // const navigateToGrowthTwo = () => {
  //   navigation.navigate('Growth two');
  // };

  return (
    <View style={styles.container}>
      <View style={styles.buttonsContainer}>
        
        <TouchableHighlight
          style={styles.button}
          onPress={navigateToDiseaseOne}
          underlayColor="#e8fbe8" // Highlight color when pressed
        >
          <Text style={styles.buttonText}>disease 1</Text>
        </TouchableHighlight>
      </View>

      {/* <TouchableHighlight
          style={styles.button}
          onPress={navigateToVarietyIdentifier}
          underlayColor="#e8fbe8" // Highlight color when pressed
        >
          <Text style={styles.buttonText}>growth 2</Text>
        </TouchableHighlight> */}

      
      <Image
        source={require('./assets/areaUI.png')} // Replace with your image source
        style={styles.backgroundImage}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonsContainer: {
    marginTop: 20,
  },
  button: {
    backgroundColor: '#87B673',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 0,
    borderColor: 'black',
    marginVertical: 20,
    width: 250,
    shadowColor: 'black',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 10,
    height: 100,
  },
  buttonText: {
    color: 'black',
    fontSize: 20,
    fontWeight: '900',
    textAlign: 'center',
    marginTop: 25,
  },
  backgroundImage: {
    width: 400, // Adjust the width as needed
    height: 400, // Adjust the height as needed
    resizeMode: 'contain',
    alignSelf: 'center',
    marginTop:150
  },
});

export default DiseaseScreen;

